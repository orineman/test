package com.infowave.c4p.admin;

import com.infowave.c4p.model.License;
import com.infowave.c4p.model.Reseller;
import com.infowave.c4p.datasource.DataException;
import com.infowave.c4p.datasource.dao.LicenseDAO;
import com.infowave.c4p.datasource.dao.DAOFactory;
import com.infowave.c4p.datasource.dao.ResellerDAO;

import java.util.*;
import java.io.OutputStream;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.io.IOException;

import org.apache.commons.cli.*;

public class LicenseGenerator
{

  private static final String RESELLER_OPT = "reseller";
  private static final String REG_CODE_OPT = "regcode";
  private static final String FIXED_OPT = "fixed";
  private static final String SUBSCRIPTION_OPT = "subscription";
  private static final String DURATION_OPT = "duration";
  private static final String MAX_USES_OPT = "maxuses";
  private static final String NB_LICENSES_OPT = "nb";
  private static final String HELP_OPT = "help";
  private static final String CODE_OPT = "code";
  private static final String OUTPUT_OPT = "output";

  private static final int REGCODE      = 0;
  private static final int FIXED        = 1;
  private static final int SUBSCRIPTION = 2;

  /** the reseller for which we are creating licenses */
  private Reseller m_reseller;

  /** Size of the licenes' code */
  private int m_licenseCodeSize = 0;

  /** The name of the file to write the output. If null we use stdout. */
  private String m_outputFilename = null;

  private int m_duration;
  private int m_maxUses;
  private int m_nbLicenses;
  private String m_code;
  private int m_licenseType = -1;




  private void createLicenses() throws DataException, IOException
  {
    LicenseCodeGenerator codeGenerator = new LicenseCodeGenerator(getLicenseCodeSize());
    List licensesCreated = new ArrayList(m_nbLicenses);
    Map codesUsed = new HashMap();
    LicenseDAO licenseDAO = DAOFactory.getLicenseDAO();
    while (licensesCreated.size() < m_nbLicenses){
      String code = codeGenerator.getCode();
      // Make sure this code is no taken already
      if (licenseDAO.countLicenses(code,m_reseller.getId()) != 0){
        continue;
      }
      // Make sure we have not previously generated that code
      if (codesUsed.containsKey(code)) {
        continue;
      }
      // We have a valid code, create the license and add it to our list.
      codesUsed.put(code,null);
      License license = new License();
      license.setCode(code);
      license.setReseller(m_reseller);
      license.setDuration(m_duration);
      license.setMaxUses(m_maxUses);
      license.setRegCode(false);
      license.setRevoked(false);
      licensesCreated.add(license);
    }
    // now we create the licenses in the database
    licenseDAO.createLicenses(licensesCreated);

    // Generate the output
    PrintWriter out;
    if (m_outputFilename == null) {
      out = new PrintWriter(System.out);
    } else {
      out = new PrintWriter(new FileOutputStream(m_outputFilename));
    }
    out.println("# license codes created on " + new Date() + " :");
    for (Iterator it = licensesCreated.iterator();it.hasNext();){
      License license = (License) it.next();
      out.println(license.getCode());
    }
    out.close();
  }



  private void createRegCodes() throws DataException
  {
    List licensesCreated = new ArrayList(m_nbLicenses);
    LicenseDAO licenseDAO = DAOFactory.getLicenseDAO();

    for (int i=0; i<m_nbLicenses;i++){
     License license = new License();
      license.setCode(m_code);
      license.setReseller(m_reseller);
      license.setDuration(m_duration);
      license.setMaxUses(m_maxUses);
      license.setRegCode(true);
      license.setRevoked(false);
      licensesCreated.add(license);
      // now we create the licenses in the database
      licenseDAO.createLicenses(licensesCreated);
    }
    System.out.println("created " + m_nbLicenses + " registration codes");
  }

  private int getLicenseCodeSize()
  {
    if (m_licenseCodeSize == 0){
      StringTokenizer tokenizer;
      tokenizer = new StringTokenizer(m_reseller.getLicenseCodeFormat(),",");
      while (tokenizer.hasMoreTokens()) {
        String val = tokenizer.nextToken();
        int intVal = Integer.parseInt(val);
        m_licenseCodeSize += intVal;
      }
    }
    return m_licenseCodeSize;
  }

  private static void printUsage(String msg)
  {
    if (msg != null) {
      System.out.println(msg);
    }
    System.out.println("Usage:");

    System.out.println("To display this message:");
    System.out.println(LicenseGenerator.class.getName() +
                       " -" + HELP_OPT);
    System.out.println("To create registration codes:");
    System.out.println(LicenseGenerator.class.getName() +
                       " -" + REG_CODE_OPT +
                       " -" + RESELLER_OPT + " <reseller's name>" +
                       " -" + CODE_OPT + " <code to use>" +
                       " -" + NB_LICENSES_OPT + " <nb Licenses to create>" +
                       " -" + MAX_USES_OPT + " <max number of uses>" +
                       " -" + DURATION_OPT + " <duration>" +
                       " -" + HELP_OPT);
    System.out.println("To create fixed term licenses:");
    System.out.println(LicenseGenerator.class.getName() +
                       " -" + FIXED_OPT +
                       " -" + RESELLER_OPT + " <reseller's name>" +
                       " -" + NB_LICENSES_OPT + " <nb Licenses to create>" +
                       " -" + DURATION_OPT + " <duration>");
    System.out.println("To create subscriptions");
    System.out.println(LicenseGenerator.class.getName() +
                       " -" + REG_CODE_OPT +
                       " -" + RESELLER_OPT + " <reseller's name>" +
                       " -" + NB_LICENSES_OPT + " <nb Licenses to create>" +
                       " -" + MAX_USES_OPT + " <max number of uses>" +
                       " -" + DURATION_OPT + " <duration>");




  }
  /**
   * creates the command line options
   * @return
   */
  private static Options createOptions()
  {
    Options options = new Options();

    options.addOption(new Option( FIXED_OPT, false,"fixed license" ));
    options.addOption(new Option( REG_CODE_OPT,false, "registration code" ));
    options.addOption(new Option( SUBSCRIPTION_OPT, false,"fixed license" ));

    options.addOption(RESELLER_OPT,true,"reseller's name");
    options.addOption(NB_LICENSES_OPT,true,"number of licenses to create");
    options.addOption(DURATION_OPT,true,"duration in days");
    options.addOption(MAX_USES_OPT,true,"maximum number of uses");
    options.addOption(OUTPUT_OPT,true,"write the output to that file");
    options.addOption(CODE_OPT,true,"registration code");
    options.addOption(HELP_OPT,false,"display a help message");

    return options;
  }
  private boolean parseCommandLineParameters (String[] args)
          throws NumberFormatException
  {
    CommandLineParser parser = new  BasicParser();
    CommandLine line = null;

    try {
    line = parser.parse(createOptions(), args );
    }
    catch(ParseException e){
      printUsage(e.getMessage());
      return false;
    }
    if (line.hasOption(HELP_OPT)){
      printUsage(null);
      return false;
    }
    // output filename
    if (line.hasOption(OUTPUT_OPT)){
      m_outputFilename = line.getOptionValue(OUTPUT_OPT);
    }

    // Find the reseller
    ResellerDAO resellerDAO = DAOFactory.getResellerDAO();
    if (!line.hasOption(RESELLER_OPT)){
      printUsage("The reseller parameter is required");
      return false;
    }
    try {
      m_reseller = resellerDAO.getByCode(line.getOptionValue(RESELLER_OPT));
      if (m_reseller == null) {
      printUsage("Invalid reseller: " + line.getOptionValue(RESELLER_OPT));
      return false;
      }
    }
    catch(DataException e) {
      printUsage(e.getMessage());
      return false;
    }
    // Number of licenses to create
    if (!line.hasOption("nb")) {
      printUsage("nb parameter required");
      return false;
    }
    m_nbLicenses = Integer.parseInt(line.getOptionValue(NB_LICENSES_OPT));

    if (line.hasOption(REG_CODE_OPT)) {
      // Reg Code
      // --------
      LicenseDAO licenseDAO = DAOFactory.getLicenseDAO();
      m_licenseType = REGCODE;
      // code
      if (!line.hasOption(CODE_OPT)) {
        printUsage(CODE_OPT + " parameter required to create a registration code");
        return false;
      }
      m_code = line.getOptionValue(CODE_OPT);
      if (m_code.length() != getLicenseCodeSize()){
        printUsage("The license code must have " + getLicenseCodeSize() + " characters");
        return false;
      }

      // Duration
      if (!line.hasOption(DURATION_OPT)){
        printUsage(DURATION_OPT + " parameter required to create a registration code");
        return false;
      }
      m_duration = Integer.parseInt(line.getOptionValue(DURATION_OPT));
    // Max uses
      if (!line.hasOption(MAX_USES_OPT)){
        printUsage(MAX_USES_OPT + " parameter required to create a registration code");
        return false;
      }
      m_maxUses = Integer.parseInt(line.getOptionValue(MAX_USES_OPT));
    } else if (line.hasOption(FIXED_OPT)) {
      // Fixed term license
      // ------------------
      m_licenseType= FIXED;
      // Max uses
      if (line.hasOption(MAX_USES_OPT)){
        printUsage("Cannot define the " + MAX_USES_OPT + " for a fixed term license");
        return false;
      }
      m_maxUses = 1;
      // Duration
      if (!line.hasOption(DURATION_OPT)){
        printUsage(DURATION_OPT + " parameter required to create a registration code");
        return false;
      }
      m_duration = Integer.parseInt(line.getOptionValue(DURATION_OPT));
    } else if (line.hasOption(SUBSCRIPTION_OPT)) {
      m_licenseType = SUBSCRIPTION;
      // Max uses
      if (!line.hasOption(MAX_USES_OPT)){
        printUsage(MAX_USES_OPT + " parameter required to create a registration code");
        return false;
      }
      m_maxUses = Integer.parseInt(line.getOptionValue(MAX_USES_OPT));
    } else {
      printUsage("You must specify a license type");
      return false;
    }
    return true;
  }

  private static  void doit(String[] args)
  {
    try {
      LicenseGenerator lg = new LicenseGenerator();
      if (lg.parseCommandLineParameters(args) == false) {
        return;
      }
      if (lg.m_licenseType ==REGCODE) {
        lg.createRegCodes();
      } else {
        lg.createLicenses();
      }
    }
    catch (Exception e){
      e.printStackTrace();
    }
  }
  public static void main (String[] args)
  {
    doit(args);
  }

}
