package com.infowave.c4p.admin;

import com.infowave.c4p.datasource.dao.LicenseDAO;
import com.infowave.c4p.datasource.dao.DAOFactory;
import com.infowave.c4p.datasource.dao.ResellerDAO;
import com.infowave.c4p.datasource.dao.AccountDAO;
import com.infowave.c4p.datasource.DataException;
import com.infowave.c4p.model.Reseller;
import com.infowave.c4p.model.License;
import com.infowave.c4p.model.Account;
import com.infowave.c4p.model.Desktop;
import com.infowave.c4p.service.delegate.LicenseManager;
import com.infowave.c4p.service.delegate.DelegateFactory;
import com.infowave.c4p.service.ServiceException;
import com.infowave.c4p.service.dto.LicenseDTO;

import java.util.List;
import java.util.Set;
import java.util.Iterator;
import java.util.StringTokenizer;

import org.apache.commons.cli.*;

/**
 * Created by IntelliJ IDEA.
 * User: vincent
 * Date: Jan 8, 2004
 * Time: 11:33:20 AM
 * To change this template use Options | File Templates.
 */
public class LicenseTerminator
{

  private static final String RESELLER_OPT = "reseller";
  private static final String REG_CODE_OPT = "regcode";
  private static final String LICENSE_OPT = "license";
  private static final String HELP_OPT = "help";
  private static final String CODE_OPT = "code";
  private static final String USERNAME_OPT = "username";
  private static final String ALL_OPT = "all";

  private static final int REGCODE        = 0;
  private static final int LICENSE        = 1;

  private String m_code;
  private int m_licenseType;
  private Reseller m_reseller;
  private int m_licenseCodeSize;
  private String m_username;
  private boolean m_revokeAllRegCodes;
  private Account m_account;

  private boolean revokeLicense() throws DataException,ServiceException
  {
    List licenses;
    LicenseDAO licenseDAO = DAOFactory.getLicenseDAO();
    licenses = licenseDAO.getByCode(m_code,m_reseller.getId());
    // This request shuold return exactly one request
    if ((licenses == null) || (licenses.size() == 0)) {
      System.out.println("Unknown license (or already revoked) code: " + m_code);
      return false;
    }
    if (licenses.size() > 1){
      System.out.println("Error: more than one license with code: " + m_code);
      return false;
    }
    License license = (License) licenses.get(0);

    // If this license is a regcode, diplay an error message
    if (license.isRegCode()) {
      System.out.println("License: " + m_code + " is a registration code");
      return false;
    }
    // If this license is already revoked, nothing to do.
    if (license.isRevoked()) {
      System.out.println("License: " + m_code + " is already revoked");
      return true;
    }
    // If the license has expired, we just revoke it without bothering checking
    // whether a desktop uses it.
    if (license.hasExpired()) {
      license.setRevoked(true);
      licenseDAO.update(license);
      System.out.println("Revoked the expired license: " + m_code);
      return true;
    }
    // if this license has never been used, we simply revoke it.
    if (license.getAccount() == null) {
      license.setRevoked(true);
      licenseDAO.update(license);
      System.out.println("Revoked the unused license: " + m_code);
      return true;
    }
    // If this license is being used but the account has no desktops (this could
    // happen if the user remove all his/her desktops).
    if (license.getAccount().getDesktops() == null) {
      license.setRevoked(true);
      licenseDAO.update(license);
      System.out.println("Revoked the unused license: " + m_code);
      return true;
    }

    // The licenses has not expired and id being used.
    // Remove the license from all of this account's desktops
    removeLicenseFromDesktops(license.getAccount());
    // Revoke the license.
    license.setRevoked(true);
    licenseDAO.update(license);
    System.out.println("Revoked the license: " + m_code);
    return true;
  }

  private boolean removeLicenseFromDesktops(Account account) throws DataException,ServiceException
  {
    LicenseManager licenseMgr = DelegateFactory.getLicenseManager();
    for (Iterator it = account.getDesktops().iterator();it.hasNext();){
      Desktop desktop = (Desktop)it.next();
      if (desktop.hasUsedLicenseCode(m_code)){
        // This desktop uses this (unexpired license). We unlicense the desktop
        // and add the other licenses one by one.
        List removedLicenses = licenseMgr.unlicense(desktop.getId());
        System.out.println("unlicensed desktop: " + desktop.getDid() + " user: " + account.getUsername());
        if ((removedLicenses != null) && (removedLicenses.size() > 1)){
          // the desktop had more than one active licenses
          boolean first = true; // we don't want to extend the first license.
          for (Iterator jt = removedLicenses.iterator();jt.hasNext();){
            LicenseDTO removed = (LicenseDTO) jt.next();
            if (!removed.getCode().equals(m_code)){
              // We must had this one back
              licenseMgr.setLicenseCode(account.getId(),desktop.getId(),
                                        removed.getCode(),!first);
              first = false;
              System.out.println("Added back license: " + removed.getCode() +
                                 " to desktop: " + desktop.getDid() +
                                 " user: " + account.getUsername());
            }
          }
        }
      }
    }
    return true;
  }

  private boolean revokeRegCode() throws DataException,ServiceException
  {
    List regCodes;
    LicenseDAO licenseDAO = DAOFactory.getLicenseDAO();
    if (m_revokeAllRegCodes) {
      regCodes = licenseDAO.getByCode(m_code,m_reseller.getId());
    } else {
      regCodes = licenseDAO.getByCodeAndUserId(m_code,m_reseller.getId(),
                                               m_account.getId());
    }
    if ((regCodes == null) || (regCodes.size() == 0)){
      System.out.println("Unknown (or already revoked) reg code: " + m_code);
      return false;
    }
    for(Iterator it = regCodes.iterator();it.hasNext();) {
      License regCode = (License)it.next();
      // If this license is not a regcode, display an error message
      if (!regCode.isRegCode()) {
        System.out.println("License: " + m_code + " is not a registration code");
        return false;
      }
      if ((!regCode.hasExpired()) && (regCode.getAccount() != null) &&
              (regCode.getAccount().getDesktops() != null)) {
        // This regcode is being used
        removeLicenseFromDesktops(regCode.getAccount());
      }
      // Now we revoke teh reg code
      regCode.setRevoked(true);
      licenseDAO.update(regCode);
      System.out.println("revoked registration code: " + m_code);
    }
    return true;
  }
  private int getLicenseCodeSize()
  {
    if (m_licenseCodeSize == 0){
      StringTokenizer tokenizer;
      tokenizer = new StringTokenizer(m_reseller.getLicenseCodeFormat(),",");
      while (tokenizer.hasMoreTokens()) {
        String val = tokenizer.nextToken();
        int intVal = Integer.parseInt(val);
        m_licenseCodeSize += intVal;
      }
    }
    return m_licenseCodeSize;
  }

  /**
   * creates the command line options
   * @return
   */
  private static Options createOptions()
  {
    Options options = new Options();

    options.addOption(new Option(LICENSE_OPT, false,"license" ));
    options.addOption(new Option(REG_CODE_OPT,false, "registration code" ));

    options.addOption(RESELLER_OPT,true,"reseller's name");
    options.addOption(CODE_OPT,true,"registration code");
    options.addOption(ALL_OPT,false, "remove all regcodes");
    options.addOption(USERNAME_OPT,true, "remove teh regcodes for this user only");

    options.addOption(HELP_OPT,false,"display a help message");

    return options;
  }
  private static void printUsage(String msg)
  {
    if (msg != null) {
      System.out.println(msg);
    }
    System.out.println("Usage:");

    System.out.println("To display this message:");
    System.out.println(LicenseGenerator.class.getName() +
                       " -" + HELP_OPT);

    System.out.println("To revoke a license:");
    System.out.println(LicenseGenerator.class.getName() +
                       " -" + LICENSE_OPT +
                       " -" + RESELLER_OPT + " <reseller's name>" +
                       " -" + CODE_OPT + " <license code>");
    System.out.println("To revoke a registration code:");
    System.out.println(LicenseGenerator.class.getName() +
                       " -" + REG_CODE_OPT +
                       " -" + RESELLER_OPT + " <reseller's name>" +
                       " -" + CODE_OPT + " <license code>" +
                       " [ -" + USERNAME_OPT + " <username>" +
                       " | -" + ALL_OPT + "]");
  }

  private boolean parseCommandLineParameters (String[] args)
          throws NumberFormatException
  {
    CommandLineParser parser = new  BasicParser();
    CommandLine line = null;

    try {
      line = parser.parse(createOptions(), args );
    }
    catch(ParseException e){
      printUsage(e.getMessage());
      return false;
    }
    if (line.hasOption(HELP_OPT)){
      printUsage(null);
      return false;
    }

    // Find the reseller
    ResellerDAO resellerDAO = DAOFactory.getResellerDAO();
    if (!line.hasOption(RESELLER_OPT)){
      printUsage("The reseller parameter is required");
      return false;
    }
    try {
      m_reseller = resellerDAO.getByCode(line.getOptionValue(RESELLER_OPT));
      if (m_reseller == null) {
      printUsage("Invalid reseller: " + line.getOptionValue(RESELLER_OPT));
      return false;
      }
    }
    catch(DataException e) {
      printUsage(e.getMessage());
      return false;
    }
    // we need a code
    if (!line.hasOption(CODE_OPT)) {
      printUsage(CODE_OPT + " parameter required to revoke a license");
      return false;
    }
    m_code = line.getOptionValue(CODE_OPT);
    if (m_code.length() != getLicenseCodeSize()){
      printUsage("The license code must have " + getLicenseCodeSize() + " characters");
      return false;
    }

    // License
    // -------
    if (line.hasOption(LICENSE_OPT)){
      m_licenseType = LICENSE;
      if (line.hasOption(USERNAME_OPT) || line.hasOption(ALL_OPT)){
        printUsage(null);
        return false;
      }

    } else if (line.hasOption(REG_CODE_OPT)) {
      // Reg Code
      // --------
      LicenseDAO licenseDAO = DAOFactory.getLicenseDAO();
      m_licenseType = REGCODE;
      if (!line.hasOption(USERNAME_OPT) && !line.hasOption(ALL_OPT)){
        printUsage(null);
        return false;
      }
      if (line.hasOption(USERNAME_OPT)) {
        if (line.hasOption(ALL_OPT)) {
          printUsage(null);
          return false;
        }
        m_username = line.getOptionValue(USERNAME_OPT);
        AccountDAO accountDAO = DAOFactory.getAccountDAO();
        try {
          m_account = accountDAO.getByUsername(m_username);
          if (m_account == null){
            printUsage("Invalid username: " + m_username);
            return false;
          }
        }
        catch(Exception e) {
          printUsage(e.getMessage());
          return false;
        }
      } else  if (line.hasOption(ALL_OPT)) {
        if (line.hasOption(USERNAME_OPT)) {
          printUsage(null);
          return false;
        }
        m_revokeAllRegCodes = true;
      } else {
        printUsage(null);
        return false;
      }

    } else {
      printUsage(null);
      return false;
    }
    return true;
  }
  private static  void doit(String[] args)
  {
    try {
      LicenseTerminator lt = new LicenseTerminator();
      if (lt.parseCommandLineParameters(args) == false) {
        return;
      }
      if (lt.m_licenseType ==REGCODE) {
        lt.revokeRegCode();
      } else {
        lt.revokeLicense();
      }
    }
    catch (Exception e){
      e.printStackTrace();
    }
  }
  public static void main (String[] args)
  {
    doit(args);
  }

}
