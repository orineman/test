package com.infowave.c4p.service.dto;

import java.util.Locale;
import java.io.Serializable;

/**
 * The Data Transfer Object for a User. 
 *
 * Created by: Vincent Aumont
 * Copyright 2003 Infowave Software, Inc.
 */
/**
 * This clas represents a user.
  */
public class UserDTO  implements Serializable
{
  private String id;
  private String firstName;
  private String lastName;
  private String email;
  private String regionalSettings;
  private Locale locale;
  private String username = null;
  private int securityQuestion;
  private String resellerName = null;

  public String getId()
  {
    return id;
  }

  public void setId(String id)
  {
    this.id = id;
  }

  public String getFirstName() {
    return firstName;
  }

  public void setFirstName(String firstName) {
    this.firstName = firstName;
  }

  public String getLastName() {
    return lastName;
  }

  public void setLastName(String lastName) {
    this.lastName = lastName;
  }

  public String getEmail() {
    return email;
  }

  public void setEmail(String email) {
    this.email = email;
  }

  public String getRegionalSettings() {
    return regionalSettings;
  }

  public void setRegionalSettings(String regionalSettings) {
    this.regionalSettings = regionalSettings;
  }

  public Locale getLocale() {
    return locale;
  }

  public void setLocale(Locale locale) {
    this.locale = locale;
  }

  public String getUsername() {
    return username;
  }

  public void setUsername(String username) {
    this.username = username;
  }

  public int getSecurityQuestion() {
    return securityQuestion;
  }

  public void setSecurityQuestion(int securityQuestion) {
    this.securityQuestion = securityQuestion;
  }

  public String getResellerName()
  {
    return resellerName;
  }

  public void setResellerName(String resellerName)
  {
    this.resellerName = resellerName;
  }
  }
