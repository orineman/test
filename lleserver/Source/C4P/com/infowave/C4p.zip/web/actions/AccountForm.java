package com.infowave.c4p.web.actions;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionMapping;

import javax.servlet.http.HttpServletRequest;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.regex.Pattern;
import java.util.regex.Matcher;

import com.infowave.c4p.util.PortalError;
import com.infowave.c4p.util.ErrorCode;

/**
 * Created by: Vincent Aumont
 * Copyright 2003 Infowave Software, Inc.
 */
public class AccountForm extends ActionForm
{
  // todo: this shouldd be put in a config file or should be reseller-secific
  private static final int MIN_LENGTH_USERNAME = 4;
  private static final int MIN_LENGTH_PASSWORD = 4;

  /** This regexp describes a the characters that are invalid */
  private static final String ILLEGAL_CHARS_REGEXP = "[^A-Za-z0-9.@_\\-~#]+";

  /** The pattern to match the regexp */
  private static Pattern ILLEGAL_CHARS_PATTERN = Pattern.compile(ILLEGAL_CHARS_REGEXP);

  /** This regexp describes a the characters that are invalid */
  private static final String EMAIL_REGEXP = "(.)+@([^\\.])+\\.(.)+";

  /** The pattern to match the regexp */
  private static Pattern EMAIL_PATTERN = Pattern.compile(EMAIL_REGEXP);

  private String username;
  private String password;
  private String passwordConfirmation;
  private String newPassword;
  private String newPasswordConfirmation;
  private String email;
  private String pcName;
  private int securityQuestion;
  private String securityAnswer;
  private String did;
  private String firstName;
  private String lastName;

  public String getUsername() {
    return username;
  }

  public void setUsername(String username) {
    if (username != null) {
      username = username.trim();
    }
    this.username = username;
  }

  public String getPassword() {
    return password;
  }

  public void setPassword(String password) {
    if (password != null){
      password = password.trim();
    }
    this.password = password;
  }

  public String getNewPassword()
  {
    return newPassword;
  }

  public void setNewPassword(String newPassword)
  {
    if (newPassword != null){
      newPassword = newPassword.trim();
    }
    this.newPassword = newPassword;
  }

  public String getNewPasswordConfirmation()
  {
    return newPasswordConfirmation;
  }

  public void setNewPasswordConfirmation(String newPasswordConfirmation)
  {
    if (newPasswordConfirmation != null) {
      newPasswordConfirmation = newPasswordConfirmation.trim();
    }
    this.newPasswordConfirmation = newPasswordConfirmation;
  }

  public String getPasswordConfirmation() {
    return passwordConfirmation;
  }

  public void setPasswordConfirmation(String passwordConfirmation) {
    if (passwordConfirmation != null) {
      passwordConfirmation = passwordConfirmation.trim();
    }
    this.passwordConfirmation = passwordConfirmation;
  }

  public String getEmail() {
    return email;
  }

  public void setEmail(String email) {
    if (email != null) {
      email = email.trim();
    }
    this.email = email;
  }

  public String getPcName() {
    return pcName;
  }

  public void setPcName(String pcName) {
    if (pcName != null) {
      pcName = pcName.trim();
    }
    this.pcName = pcName;
  }

  public int getSecurityQuestion() {
    return securityQuestion;
  }

  public void setSecurityQuestion(int securityQuestion) {
    this.securityQuestion = securityQuestion;
  }

  public String getSecurityAnswer() {
    return securityAnswer;
  }

  public void setSecurityAnswer(String securityAnswer) {
    if (securityAnswer != null){
      securityAnswer = securityAnswer;
    }
    this.securityAnswer = securityAnswer;
  }

  public String getDid()
  {
    return did;
  }

  public void setDid(String did)
  {
    if (did != null) {
      did = did.trim();
    }
    this.did = did;
  }

  public String getFirstName() {
    return firstName;
  }

  public void setFirstName(String firstName) {
    if (firstName != null) {
      firstName = firstName.trim();
    }
    this.firstName = firstName;
  }

  public String getLastName() {
    return lastName;
  }

  public void setLastName(String lastName) {
    if (lastName != null) {
      lastName = lastName.trim();
    }
    this.lastName = lastName;
  }

  /**
   * Validates the form parameters.
   *
   * @param mapping
   * @param request
   * @return A (possibly empty) list of errors.
   */

  public List validateInput(ActionMapping mapping,
                            HttpServletRequest request)
  {
    List errors = new ArrayList(3);

    // // Username
    validateUsername(mapping,request,errors);

    // Password
    validateUsername(mapping,request,errors);

    // Confirmation password
    if ((passwordConfirmation == null) || (passwordConfirmation.length() == 0)){
      errors.add(new PortalError(ErrorCode.DATA_ENTRY_PASSWORD_CONF_MISSING_ERROR));
    }

    // Password must match
    if ((password != null) && (password.length() != 0) &&
            (passwordConfirmation != null) && (passwordConfirmation.length() != 0))
    {
      if (!password.equals(passwordConfirmation)) {
        errors.add(new PortalError(ErrorCode.DATA_ENTRY_PASSWORDS_DONT_MATCH_ERROR));
      }
    }
    // PC name
    validatePcName(mapping,request,errors);

    // Email
    boolean required = true;
    validateEmail(mapping,request,required,errors);

    // Security answer
    validateSecurityAnswer(mapping,request,errors);

    return errors;
  }


  /**
   * Validate he username field.
   * @param mapping
   * @param request
   * @return
   */
  protected List validateUsername(ActionMapping mapping,
                                  HttpServletRequest request,
                                  List errors)
  {
    if ((username == null) || (username.length() == 0)){
      errors.add(new PortalError(ErrorCode.DATA_ENTRY_USERNAME_MISSING_ERROR));
    }  else if (username.length() <MIN_LENGTH_USERNAME){
      errors.add(new PortalError(ErrorCode.DATA_ENTRY_USERNAME_FORMAT_ERROR,
                                 Integer.toString(MIN_LENGTH_USERNAME)));
    } else {
      Matcher matcher = ILLEGAL_CHARS_PATTERN.matcher(username);
      if (matcher.find()) {
        errors.add(new PortalError(ErrorCode.DATA_ENTRY_USERNAME_FORMAT_ERROR));
      }
    }
    return errors;
  }

  /**
   * Validate the first name field.
   * @param mapping
   * @param request
   * @return
   */
  protected List validateFirstName(ActionMapping mapping,
                                  HttpServletRequest request,
                                  boolean required,
                                  List errors)
  {
    if (required) {
      if ((firstName == null) || (firstName.length() == 0)){
        // todo creat an error, if we ever need one.
        //errors.add(new PortalError(ErrorCode.DATA_ENTRY_USERNAME_MISSING_ERROR));
      }
    }
    if ((firstName == null) || (firstName.length() == 0)){
      Matcher matcher = ILLEGAL_CHARS_PATTERN.matcher(firstName);
      if (matcher.find()) {
        errors.add(new PortalError(ErrorCode.DATA_ENTRY_FIRSTNAME_FORMAT_ERROR));
      }
    }
    return errors;
  }

  /**
   * Validate the last name field.
   * @param mapping
   * @param request
   * @return
   */
  protected List validateLastName(ActionMapping mapping,
                                  HttpServletRequest request,
                                  boolean required,
                                  List errors)
  {
    if (required) {
      if ((lastName == null) || (lastName.length() == 0)){
        // todo creat an error, if we ever need one.
        //errors.add(new PortalError(ErrorCode.DATA_ENTRY_USERNAME_MISSING_ERROR));
      }
    }
    if ((lastName != null) && (lastName.length() != 0)){
      Matcher matcher = ILLEGAL_CHARS_PATTERN.matcher(lastName);
      if (matcher.find()) {
        errors.add(new PortalError(ErrorCode.DATA_ENTRY_LASTNAME_FORMAT_ERROR));
      }
    }
    return errors;
  }

  /**
   * Validate the password field.
   * @param mapping
   * @param request
   * @return
   */
  protected List validatePassword(ActionMapping mapping,
                                  HttpServletRequest request,
                                  List errors)
  {
    if ((password == null) || (password.length() == 0)){
      errors.add(new PortalError(ErrorCode.DATA_ENTRY_PASSWORD_MISSING_ERROR));
    } else if (password.length() <MIN_LENGTH_PASSWORD){
      errors.add(new PortalError(ErrorCode.DATA_ENTRY_PASSWORD_FORMAT_ERROR,
                                 Integer.toString(MIN_LENGTH_PASSWORD)));
    } else {
      Matcher matcher = ILLEGAL_CHARS_PATTERN.matcher(password);
      if (matcher.find()) {
        errors.add(new PortalError(ErrorCode.DATA_ENTRY_PASSWORD_FORMAT_ERROR));
      }
    }
    return errors;
  }
  /**
   * Validate the password field.
   * @param mapping
   * @param request
   * @return
   */
  protected List validateNewPassword(ActionMapping mapping,
                                  HttpServletRequest request,
                                  List errors)
  {
    if ((newPassword == null) || (newPassword.length() == 0)){
      errors.add(new PortalError(ErrorCode.DATA_ENTRY_PASSWORD_MISSING_ERROR));
    } else if (newPassword.length() <MIN_LENGTH_PASSWORD){
      errors.add(new PortalError(ErrorCode.DATA_ENTRY_PASSWORD_FORMAT_ERROR,
                                 Integer.toString(MIN_LENGTH_PASSWORD)));
    } else {
      Matcher matcher = ILLEGAL_CHARS_PATTERN.matcher(newPassword);
      if (matcher.find()) {
        errors.add(new PortalError(ErrorCode.DATA_ENTRY_PASSWORD_FORMAT_ERROR));
      }
    }
    return errors;
  }

  /**
   * Validate the password field.
   * @param mapping
   * @param request
   * @return
   */
  protected List validateNewPasswordConfirmation(ActionMapping mapping,
                                  HttpServletRequest request,
                                  List errors)
  {
    boolean match = false;
    if ((newPassword != null) && (newPassword.length() != 0) &&
            (newPasswordConfirmation != null) && (newPasswordConfirmation.length() != 0))
    {
      if (newPassword.equals(newPasswordConfirmation)) {
        match = true;
      }
    }
    
    if (!match) {
      errors.add(new PortalError(ErrorCode.DATA_ENTRY_PASSWORDS_DONT_MATCH_ERROR));
    }
    return errors;
  }



  /**
   * Validate the PC Name  field.
   * @param mapping
   * @param request
   * @return
   */
  protected List validatePcName(ActionMapping mapping,
                                HttpServletRequest request,
                                List errors)
  {
    if ((pcName == null) || (pcName.length() == 0)){
      errors.add(new PortalError(ErrorCode.DATA_ENTRY_PC_NAME_MISSING_ERROR));
    }
    return errors;
  }

  /**
   * Validate the Email  field.
   * @param mapping
   * @param request
   * @return
   */
  protected List validateEmail(ActionMapping mapping,
                               HttpServletRequest request,
                               boolean required,
                               List errors)
  {
    if (required) {
      if ((email == null) || (email.length() == 0)){
        errors.add(new PortalError(ErrorCode.DATA_ENTRY_EMAIL_MISSING_ERROR));
      }
    }
    if ((email != null) && (!email.equals(""))) {
      Matcher matcher = EMAIL_PATTERN.matcher(email);
      if (!matcher.find()) {
        errors.add(new PortalError(ErrorCode.DATA_ENTRY_EMAIL_FORMAT_ERROR));
      }
    }
    return errors;
  }

  /**
   * Validate the Email  field.
   * @param mapping
   * @param request
   * @return
   */
  protected List validateSecurityAnswer(ActionMapping mapping,
                                        HttpServletRequest request,
                                        List errors)
  {
    if ((securityAnswer == null) || (securityAnswer.length() == 0)){
      errors.add(new PortalError(ErrorCode.DATA_ENTRY_SEC_ANSWER_MISSING_ERROR));
    }

    return errors;
  }

  //-------------------------------------------------------------- Test methods
  private static void testValidateInput() throws Exception
  {
    List errors;
    /*
    CreateAccountForm f = new CreateAccountForm();
    f.setUsername("QWpppp/");
    f.setPassword("pppppp");
    f.setPasswordConfirmation("l");
    f.setSecurityAnswer("popopopo");
    f.setEmail("popo@popo.com");
    List errors = f.validateInput(null,null);
    for (Iterator it = errors.iterator();it.hasNext();){
    System.out.println((PortalError) it.next());
    }
    */
    // Empty form
    CreateAccountForm empty = new CreateAccountForm();
    errors = empty.validateInput(null,null);
    System.out.println("Errors for the empty form:");
    for (Iterator it = errors.iterator();it.hasNext();){
      System.out.println((PortalError) it.next());
    }
    // All wrong
    CreateAccountForm wrong = new CreateAccountForm();
    wrong.setUsername("Qwewe/weweW");
    wrong.setPassword("lklklklkk");
    wrong.setPasswordConfirmation("l");
    wrong.setSecurityAnswer("");
    wrong.setEmail("wewewewe");
    errors = wrong.validateInput(null,null);
    System.out.println("Errors for the all-wrong form:");
    for (Iterator it = errors.iterator();it.hasNext();){
      System.out.println((PortalError) it.next());
    }
    // All good
    CreateAccountForm good = new CreateAccountForm();
    good.setUsername("QweweeweW");
    good.setPassword("qqqqq");
    good.setPasswordConfirmation("qqqqq");
    good.setSecurityAnswer("uiuiuiui");
    good.setEmail("wewewewe@opioi.lilik");
    errors = good.validateInput(null,null);
    System.out.println("Errors for the all-good form:");
    for (Iterator it = errors.iterator();it.hasNext();){
      System.out.println((PortalError) it.next());
    }

  }

  public static void main(String[] args) {
    try {
      testValidateInput();
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

}


