package com.infowave.c4p.web.util;

import org.apache.commons.httpclient.*;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.methods.MultipartPostMethod;
import org.apache.commons.httpclient.methods.multipart.FilePart;
import org.apache.commons.logging.LogFactory;
import org.apache.commons.logging.Log;
import org.apache.commons.fileupload.*;

import javax.servlet.http.HttpServletRequest;
import java.util.*;
import java.security.InvalidParameterException;
import java.io.*;

import com.infowave.c4p.web.config.Configurator;
import com.infowave.c4p.util.ApplicationParameters;



/**
 */
public class RequestRedirector
 {

public static class FileInfo
{
 public FileInfo(File file, String filename,String filesystemName,
                 String fieldName)
 {
   this.filesystemName = filesystemName;
   this.file = file;
   this.filename = filename;
   this.fieldName = fieldName;

 }

  File file;
  String filename;
  String filesystemName;
  String fieldName;

  public String toString()
  {
    return "name: " + filename + " - fs name: " + filesystemName + " lcoal: " + file.getName();
  }
}


  /** The class's logger */
  private static Log m_log = LogFactory.getLog(RequestRedirector.class);

  private static final String POST = "post";
  private static final String GET = "get";



  private NameValuePair[] m_parameters = null;
  private String m_method;
  private String m_redirectTo;
  private Map m_headers = null;
  private String m_queryString = null;
  private boolean m_isMultiPart = false;
  private List m_uploadedFiles;
  private boolean m_valid = true;


  public RequestRedirector (String redirectTo,Map headers)
  {
    m_method = GET;
    m_queryString = null;
    m_parameters = null;
    m_redirectTo = redirectTo;
    m_headers = headers;
  }

/*
    public RequestRedirector (HttpServletRequest request,
                            String redirectTo,
                            Map headers)
  {


    m_method = request.getMethod();
    m_queryString = request.getQueryString();
    m_parameters = getParametersAsNVP(request);
    m_redirectTo = redirectTo;
    m_headers = headers;
  }
  */
   public RequestRedirector (HttpServletRequest request,
                            String redirectTo,
                            Map headers)
  {
    m_method = request.getMethod();
    m_queryString = request.getQueryString();
    m_redirectTo = redirectTo;
    m_headers = headers;

    // get the request's parameters

    if (FileUpload.isMultipartContent(request)){
      m_isMultiPart = true;
      m_valid = getMultiPartRequestParameters(request);
    } else {
      m_parameters = getParametersAsNVP(request);
    }
  }


  /**
   * Builds the appropriate method to execute the request.
   * @return
   */
  public HttpMethod getMethod()
  {
    HttpMethod method;
    // Create the method (post or get)
    if (GET.equalsIgnoreCase(m_method)){
      method = new GetMethod(m_redirectTo);
      if (m_queryString != null) {
        method.setQueryString(m_queryString);
      }
    } else if (POST.equalsIgnoreCase(m_method)) {
      if (m_isMultiPart) {
        MultipartPostMethod multipartPost = new MultipartPostMethod(m_redirectTo);
        if (m_queryString != null){
          multipartPost.setQueryString(m_queryString);
        }
        // Important: The orders of the parameters matters for the ICM: tyhe
        // files must be sent first, then the non-file parameters.
        
        // Add the files
        if (m_uploadedFiles != null) {
          for (Iterator it = m_uploadedFiles.iterator();it.hasNext();) {
            FileInfo info = (FileInfo) it.next();
            try {
              m_log.debug("getMethod - Adding file: " + info.file.getName() + " original filename:" + info.filename + " field name:" + info.fieldName);
              //multipartPost.addParameter(info.filename,info.filesystemName,info.file);
              //multipartPost.addParameter(info.fieldName,"h:\\poub\\" + info.filename,info.file);
              FilePart part = new FilePart(info.fieldName,info.filename,info.file);
              multipartPost.addPart(part);
            }
            catch(FileNotFoundException e){
              m_log.error("getMethod - file not found",e);
            }
          }
        }
        // Add the parameters
        if (m_parameters != null) {
          for (int i=0;i<m_parameters.length;i++){
            multipartPost.addParameter(m_parameters[i].getName(),
                                       m_parameters[i].getValue());
            m_log.debug("getMethod - add parameter: " +
                        m_parameters[i].getName() + "=" +  m_parameters[i].getValue());
          }
        }


        method = multipartPost;
      } else {
        PostMethod post;
        post = new PostMethod(m_redirectTo);
        if (m_parameters != null){
          post.setRequestBody(m_parameters);
        }
        // The ICM mixes URI and for parameters in its post requests
        // Example:
        // <form action="/html/p/apps//lsfiles//?did=5Ai4KasZ&LLMethod=GetNavigatePage"
        //       method="POST" enctype="application/x-www-form-urlencoded">
        //   <input type="image" src="x-res/goTo_6.gif?did=5Ai4KasZ"
        //               name="Go To" alt="Go To">
        //   </input>
        // </form>
        // In this case, we can't just pass the did and LLMethod parameters in the
        // request's body because the ICM expects them in the query string.
        if (m_queryString != null){
          post.setQueryString(m_queryString);
        }
        method = post;
      }
    } else {
      throw new InvalidParameterException("Invalid method: " + m_method);
    }
    // Set the headers
    if (m_headers != null){
      for (Iterator it= m_headers.keySet().iterator();it.hasNext();) {
        String header = (String) it.next();
        method.setRequestHeader(header,(String)m_headers.get(header));
      }
    }
    return method;
  }




  /**
   * Extracts the request parameters and store them in an array of name/value
   * pairs.
   * @param request
   * @return
   */
  private NameValuePair[] getParametersAsNVP(HttpServletRequest request)
  {
    java.util.Enumeration e = request.getParameterNames();
    List params = new ArrayList (12);
    while (e.hasMoreElements()) {
      String name = (String)e.nextElement();
      String value = request.getParameter(name);
      NameValuePair nvp = new NameValuePair(name,value);
      m_log.debug(name + "=" + value);
      params.add(nvp);
    }
    NameValuePair[] nvps = new NameValuePair[params.size()];
    for (int i=0;i<params.size();i++){
      nvps[i] = (NameValuePair)params.get(i);
    }
    return nvps;
  }
  private NameValuePair[] getQueryStringForPostMethod()
  {
    NameValuePair[] nvps = null;
    if (m_parameters != null) {
      for (int i=0;i<m_parameters.length;i++){

      }
    }
    return null;
  }


  private boolean getMultiPartRequestParameters(HttpServletRequest request)
  {
    boolean valid = false;
    try {
      String dir = ApplicationParameters.instance().getUploadDirectoryPath();
      DiskFileUpload upload = new DiskFileUpload();
      upload.setRepositoryPath(dir);
      List  items = upload.parseRequest(request);
      List params = new ArrayList (12);
      m_uploadedFiles = new ArrayList(1);

      Iterator iter = items.iterator();
      int counter = 0;
      while (iter.hasNext()) {
        FileItem item = (FileItem) iter.next();
        if (item.isFormField()) {
          params.add(new NameValuePair(item.getFieldName(),item.getString()));
        } else {
          String sessionId = request.getSession().getId();
          String fieldName = item.getFieldName();
          String fileName = item.getName();
          String contentType = item.getContentType();
          boolean isInMemory = item.isInMemory();
          long sizeInBytes = item.getSize();
          File uploadedFile = new File(dir + "/" + sessionId + "_" + counter++);
          item.write(uploadedFile);
          FileInfo fileInfo = new FileInfo(uploadedFile,fileName,
                                           uploadedFile.getAbsolutePath(),
                                           fieldName);
          m_uploadedFiles.add(fileInfo);
          m_log.debug("file: " + fileInfo);
        }
      }
      m_parameters = new NameValuePair[params.size()];
      for (int i=0;i<params.size();i++){
        m_parameters[i] = (NameValuePair)params.get(i);
      }
      valid = true;
    }
    catch (Exception e) {
      m_valid = false;
      m_log.error("Cannot process multipart request",e);
      if (m_uploadedFiles != null) {
        for (Iterator it = m_uploadedFiles.iterator();it.hasNext();) {
          FileInfo fileInfo = (FileInfo) it.next();
          fileInfo.file.delete();
        }
      }
    }
    return valid;
  }


  public void cleanup()
  {
    if (m_uploadedFiles != null) {
      for (Iterator it = m_uploadedFiles.iterator();it.hasNext();) {
        FileInfo info = (FileInfo) it.next();
        if (info.file.delete() == false) {
          m_log.warn("Cannot delete file:" + info.file);
        }
      }
    }
  }
// --------------------------------------------------------------------------

  private static void testGet() throws Exception
  {
    String url = "https://files.laplink.com/lsfiles/F:/Music/60's/Beach%20Boys%20-%20Good%20Vibrations.mp3?GetActions=1&did=5Ai4KasZ";
     url = "https://files.laplink.com/lsfiles/F:/Music/60's/Beach%20Boys%20-%20Good%20Vibrations.mp3?did=5Ai4KasZ&GetActions=1";
    url = "http://www.google.com/ popo";
    String username = "c4test";
    String password = "ignored";
    String authorization = "Basic " + Base64Encoder.encode(username + ":" + password);
    HttpMethod method = new GetMethod(url);
    method.setRequestHeader("Authorization",authorization);

    HttpClient client = new HttpClient();
    int res = client.executeMethod(method);
    System.out.println("return: " + res);
    System.out.println(method.getResponseBodyAsString());
  }

  private static void testURI() throws Exception
  {
    try {
    String url = "http://www.google.com/ popo";
      url = "f:/music/60's/foo bar/toto titi";
     URI uri = new URI(url);
      System.out.println("escapes path: " + uri.getEscapedPath());
      System.out.println("escapes uri: " + uri.getEscapedURI());
    } catch(Exception e){
      e.printStackTrace();
    }
  }
  private static void testPost() throws Exception
  {
    String url = "https://files.laplink.com/lsfiles//F:/Music/60's?did=5Ai4KasZ&LLMethod=GetNavigatePage";
    url = "https://files.laplink.com/lsfiles//F:/Music/60's";
    url = "https://files.laplink.com";
    //url="https://easyweb.tdcanadatrust.com/";
    HttpMethod method;
    method = new PostMethod(url);
    //method = new GetMethod(url);

    String username = "vtang";
    String password = "ignored";
    String authorization = "Basic "
            + Base64Encoder.encode(username + ":" + password);
    method.addRequestHeader("Authorization",authorization);

    if (method instanceof PostMethod){
      PostMethod post = (PostMethod) method;
      NameValuePair[] nvps = new NameValuePair[2];
      nvps[0] = new NameValuePair("did","5Ai4KasZ");
      nvps[1] = new NameValuePair("LLMethod","GetNavigatePage");
      //post.setQueryString(nvps);
      //post.addParameters(nvps);
      //post.setQueryString(nvps);
      post.setRequestBody(nvps);
      //post.setRequestContentLength(37);


      NameValuePair[] params = post.getParameters();
      System.out.println("method: " + method.getClass().getName() + " " +method.getPath());
      System.out.println("The parameters:");
      for (int i=0;i<params.length;i++){
        System.out.println("param: " + params[i].getName() + " = " + params[i].getValue());
      }

    }

    HttpClient client = new HttpClient();
    /*
     client.getState().setCredentials(
            null,
            null,
            new UsernamePasswordCredentials(username, password)
        );
        */
    int res = client.executeMethod(method);
    System.out.println("return: " + res);
    InputStream is = method.getResponseBodyAsStream();
    byte[] buff = new byte[256];
    //while (is.read(buff) != -1) {
     //  System.out.println("-");
    //}
    System.out.println(method.getResponseBodyAsString());
    method.releaseConnection();

  }


  public static void main(String[] arhs)
  {
    try{
      //testPost();
      testGet();
      //testURI();
    }
    catch(Exception e){e.printStackTrace();}

  }

}
