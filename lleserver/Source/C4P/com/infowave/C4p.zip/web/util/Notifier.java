package com.infowave.c4p.web.util;

import com.infowave.c4p.web.config.Configurator;
import com.infowave.c4p.util.StringManager;
import com.infowave.c4p.util.ApplicationParameters;

import java.util.Properties;
import java.util.Date;
import java.util.Locale;

import org.apache.commons.logging.LogFactory;
import org.apache.commons.logging.Log;

import javax.mail.Session;
import javax.mail.Message;
import javax.mail.Transport;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.InternetAddress;


public class Notifier
{
  private static final String NEW_ACCOUNT_SUBJECT_KEY = "mail.newAccountSubject";
  private static final String NEW_ACCOUNT_BODY_KEY = "mail.newAccountBody";
  private static final String NEW_ACCOUNT_FROM_KEY = "mail.newAccountFrom";

  /** The class's logger */
  private static Log m_log = LogFactory.getLog(Notifier.class);

  /** The class' unique instance */
  private static Notifier m_instance = null;

  // ----------------------------------------------------------- Public methods

  public void notifyAccountCreation(String reseller, String to,Locale locale)
  {
    StringManager stringMgr;
    if (locale != null) {
      stringMgr = StringManager.getManager(reseller);
    } else {
      stringMgr = StringManager.getManager("reseller",locale);
    }
    if (stringMgr == null){
      m_log.error("Cannot send mail- no String manager for reseller: " + reseller);
      return;
    }
    String subject = stringMgr.getString(NEW_ACCOUNT_SUBJECT_KEY);
    String body = stringMgr.getString(NEW_ACCOUNT_BODY_KEY);
    String from = stringMgr.getString(NEW_ACCOUNT_FROM_KEY);

    send(to,from,subject,body);
  }

  // ------------------------------------------------------------ Helper methods
    /**
   * Returns the class' unique instance
   */
  public static Notifier instance()
  {
    if (m_instance == null) {
      m_instance = new Notifier();
      m_instance.initialize();
    }
    return m_instance;
  }

  /**
   * Sends a message.
   */
  public void send (String to, String from, String subject, String content)
  {
    try {
      Properties props = System.getProperties();
      Session session = Session.getDefaultInstance(props, null);
      Message msg = new MimeMessage(session);
      msg.setFrom(new InternetAddress(from));
      msg.setRecipients(Message.RecipientType.TO,
                        InternetAddress.parse(to, false));
      msg.setSubject(subject);
      msg.setText(content);
      msg.setHeader("X-Mailer", "MsgSend");
      msg.setSentDate(new Date());
      Transport.send(msg);
    }
    catch (Exception e) {
      String msg = "Cannot send message from: " + from + " to: " + to;
      m_log.warn(msg,e);
    }
  }


  /**
   * Initialize the class.
   */
  private void initialize()
  {
    // Get the SMTP host
    Properties props = System.getProperties();
    String smtpHost = ApplicationParameters.instance().getSmtpServer();
    m_log.debug("SMTP Host: " + smtpHost);

    if (smtpHost != null) {
      props.put("mail.smtp.host", smtpHost);
    }

  }



}
